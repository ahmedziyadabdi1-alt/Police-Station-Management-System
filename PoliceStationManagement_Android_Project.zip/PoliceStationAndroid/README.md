# Police Station Management System — Android

This is an Android Studio project adapted from the supplied C++ project.

## Included features
- Login screen (demo credentials: `admin` / `pass`)
- Dashboard with total record count
- Create, view, search, edit and delete criminal records
- Personal, court, physical description, police station and FIR/arrest fields
- SQLite local database (`police_station.db`)
- English interface

## Open and build
1. Install Android Studio (recent stable version).
2. Extract this folder and choose **Open** in Android Studio.
3. Allow Gradle sync and install the Android SDK platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run**. To create an APK, use **Build → Build APK(s)**.

## Demo login
- Username: `admin`
- Password: `pass`

## Important security note
This is a starter/demo application. The demo login is hard-coded and the database is stored locally without encryption or server-side access control. Do not enter real confidential police or personal data until proper authentication, encryption, backups, audit logging, role permissions and legal/privacy review are implemented.

## Source project mapping
The original C++ menu supported add, modify, display, delete and list-all criminal records. These operations are represented in the Android interface. The Android app uses SQLite instead of the original `jail.txt` flat file.
