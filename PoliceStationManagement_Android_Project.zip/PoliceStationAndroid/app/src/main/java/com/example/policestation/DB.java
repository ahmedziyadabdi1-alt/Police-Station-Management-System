package com.example.policestation;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c) { super(c, "police_station.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE records(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, sex TEXT, address TEXT, age TEXT, court TEXT, state TEXT, crime TEXT, act TEXT, complexion TEXT, face TEXT, mark TEXT, height TEXT, eyes TEXT, station TEXT, fir TEXT, arrestDate TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) { }
    public Cursor all(String q) {
        SQLiteDatabase d=getReadableDatabase();
        return d.rawQuery("SELECT * FROM records WHERE code LIKE ? OR name LIKE ? OR crime LIKE ? ORDER BY id DESC",new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"});
    }
    public boolean save(ContentValues v, long id) {
        SQLiteDatabase d=getWritableDatabase();
        if(id==0) return d.insert("records",null,v)>0;
        return d.update("records",v,"id=?",new String[]{String.valueOf(id)})>0;
    }
    public void delete(long id) { getWritableDatabase().delete("records","id=?",new String[]{String.valueOf(id)}); }
    public int count() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM records",null); c.moveToFirst(); int n=c.getInt(0); c.close(); return n; }
}
